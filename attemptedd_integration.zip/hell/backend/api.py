from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse, FileResponse
import uuid, os

from pipeline.extractor import upload_and_extract, analyze_project_structure
from pipeline.segregator import segregate_files
from pipeline.rag_builder import build_rag_knowledge_base
from pipeline.analyzer import process_files
from pipeline.output import create_output_zip, save_results

app = FastAPI(title="Code‑Review Pipeline")

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/process-zip")
async def process_zip(file: UploadFile = File(...)):
    print("uploaded")
    # 1) Save upload
    uid = uuid.uuid4().hex
    zip_path = os.path.join(UPLOAD_DIR, f"{uid}.zip")
    with open(zip_path, "wb") as buffer:
        buffer.write(await file.read())

    # 2) Run pipeline
    extract_root = upload_and_extract(zip_path, extract_root=os.path.join(UPLOAD_DIR, uid))
    aim, proj_type, configs = analyze_project_structure(extract_root)
    segregated, _special = segregate_files(extract_root)
    vectorstore, emb_mgr = build_rag_knowledge_base(segregated, aim, configs)
    results = process_files(segregated, proj_type, aim, emb_mgr)

    # 3) Package output
    out_zip = create_output_zip(zip_path)
    save_results(results)

    # 4) Return JSON + link to download
    return JSONResponse({
        "project_type": proj_type,
        "files_processed": len(results),
        "download_zip": f"/download/{os.path.basename(out_zip)}",
        "results": results
    })

@app.get("/download/{filename}")
def download_file(filename: str):
    path = os.path.join(os.getcwd(), filename)
    if not os.path.exists(path):
        raise HTTPException(404, "File not found")
    return FileResponse(path, media_type="application/zip", filename=filename)
