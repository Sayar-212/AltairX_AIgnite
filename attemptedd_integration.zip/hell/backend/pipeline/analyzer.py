import re, uuid
from datetime import datetime
import google.generativeai as genai
from .config import FRAMEWORK_PATTERNS

# Ensure API key configured somewhere before import
def analyze_code(code_input, fname, project_type, aim=None, similar_files=None):
    model = genai.GenerativeModel(model_name='gemini-2.0-flash')
    # build prompt (omitted for brevity; copy from notebook)
    prompt = f"Analyze file {fname} for {project_type} best practices..."
    resp = model.generate_content(contents=[{'role':'user','parts':[prompt]}])
    return resp.text

def extract_update(text):
    blocks = re.findall(r"```[\s\S]*?```", text)
    return blocks[-1].strip('```') if blocks else None

from .rag_builder import VectorEmbeddingManager

def process_files(segregated, project_type, project_aim, embedding_manager):
    results = []
    for ext, paths in segregated.items():
        for p in paths:
            with open(p,'r',encoding='utf-8',errors='ignore') as f:
                code = f.read()
            similar = None
            if embedding_manager.vectorstore:
                similar = embedding_manager.similarity_search(code, k=3)
            analysis = analyze_code(code, p, project_type, aim=project_aim, similar_files=similar)
            updated = extract_update(analysis)
            results.append({'file':p, 'analysis':analysis, 'updated':updated})
    return results