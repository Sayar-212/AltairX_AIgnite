# Expanded supported extensions
EXT_DIRS = [
    # Web & Frontend
    'html','css','js','jsx','ts','tsx','vue','svelte','json','xml',
    # Backend & Server
    'py','php','rb','java','go','rs','cs','c','cpp',
    # Config & Build
    'yaml','yml','toml','ini','conf','env','lock','json','md','gitignore',
    # Scripts & Others
    'sh','bat','sql','pl','r','scala','bash','dockerfile'
]

# Frontend framework detection patterns
FRAMEWORK_PATTERNS = {
    'react': [
        'import React', 'React.Component', 'useState', 'useEffect',
        'ReactDOM', 'createRoot', 'jsx', 'tsx'
    ],
    'angular': [
        '@Component', '@NgModule', '@Injectable', 'ngOnInit',
        'ngAfterViewInit', 'ngFor', 'ngIf'
    ],
    'vue': [
        'Vue.createApp', 'defineComponent', 'setup()', '<template>',
        '@vue/cli', 'Composition API', 'Options API'
    ],
    'nodejs': [
        'require(', 'module.exports', 'express()', 'npm', 'package.json',
        'node_modules', 'process.env'
    ]
}