import os, shutil, zipfile, json
from .config import EXT_DIRS, FRAMEWORK_PATTERNS

# Step 1: unzip the uploaded file
def upload_and_extract(zip_path: str, extract_root: str = "uploads") -> str:
    if os.path.exists(extract_root):
        shutil.rmtree(extract_root)
    os.makedirs(extract_root, exist_ok=True)
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(extract_root)
    return extract_root

# Step 2: detect project structure and configs
def analyze_project_structure(extract_root: str):
    project_aim = None
    project_type = 'unknown'
    config_files = {}
    framework_scores = {fw: 0 for fw in FRAMEWORK_PATTERNS}

    # Walk files
    for root, _, files in os.walk(extract_root):
        for file in files:
            lower = file.lower()
            path = os.path.join(root, file)
            # README.md
            if lower == 'readme.md':
                try:
                    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                        project_aim = f.read()
                except:
                    pass
            # config files
            if lower in ['package.json','tsconfig.json','vite.config.js','angular.json']:
                try:
                    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                        config_files[lower] = f.read()
                except:
                    pass
            # framework pattern matching
            ext = os.path.splitext(lower)[1][1:]
            if ext in EXT_DIRS:
                try:
                    content = open(path, 'r', encoding='utf-8', errors='ignore').read()
                    for fw, patterns in FRAMEWORK_PATTERNS.items():
                        for pat in patterns:
                            if pat in content:
                                framework_scores[fw] += 1
                except:
                    pass

    # Determine type via package.json first
    if 'package.json' in config_files:
        import json as _json
        try:
            pkg = _json.loads(config_files['package.json'])
            deps = {**pkg.get('dependencies', {}), **pkg.get('devDependencies', {})}
            if 'react' in deps:
                project_type = 'react'
            elif 'vue' in deps:
                project_type = 'vue'
            elif '@angular/core' in deps:
                project_type = 'angular'
            else:
                project_type = 'nodejs'
        except:
            pass
    # fallback to pattern detection
    if project_type == 'unknown':
        best = max(framework_scores.items(), key=lambda x: x[1])
        if best[1] > 0:
            project_type = best[0]

    return project_aim, project_type, config_files
