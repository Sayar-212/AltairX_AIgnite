import os, zipfile, json

def create_output_zip(orig_zip: str) -> str:
    out_zip = orig_zip.rsplit('.',1)[0] + '_updated.zip'
    with zipfile.ZipFile(out_zip,'w',zipfile.ZIP_DEFLATED) as zout:
        base = os.path.dirname(orig_zip)
        for root, _, files in os.walk(base):
            for fn in files:
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, base)
                zout.write(full, arc)
    return out_zip

def save_results(results):
    with open('analysis_results.json','w') as f:
        json.dump(results, f, indent=2)