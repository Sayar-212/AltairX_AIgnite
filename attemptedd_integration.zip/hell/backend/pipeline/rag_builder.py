import os
# - from langchain.document_loaders import Document
from langchain_core.documents import Document

# from langchain.embeddings import HuggingFaceEmbeddings, OpenAIEmbeddings
from langchain_community.embeddings import HuggingFaceEmbeddings, OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain.vectorstores import Chroma, FAISS
from langchain_community.vectorstores import Chroma, FAISS
from .config import EXT_DIRS

class VectorEmbeddingManager:
    def __init__(self, embedding_model='all-MiniLM-L6-v2', embedding_type='huggingface', persist_directory='./chroma_db', openai_api_key=None):
        if embedding_type == 'huggingface':
            self.embeddings = HuggingFaceEmbeddings(model_name=embedding_model)
            self.dimension = 384
        elif embedding_type == 'openai':
            os.environ['OPENAI_API_KEY'] = openai_api_key or ''
            self.embeddings = OpenAIEmbeddings()
            self.dimension = 1536
        else:
            raise ValueError('Unsupported embedding type')
        self.persist_directory = persist_directory
        self.vectorstore = None

    def create_vectorstore(self, documents, vectorstore_type='chroma'):
        if vectorstore_type == 'chroma':
            self.vectorstore = Chroma.from_documents(documents, self.embeddings, persist_directory=self.persist_directory)
        else:
            self.vectorstore = FAISS.from_documents(documents, self.embeddings)
        return self.vectorstore

    def add_documents(self, documents):
        if not self.vectorstore:
            raise ValueError('Vectorstore not initialized')
        self.vectorstore.add_documents(documents)
        return self.vectorstore

    def similarity_search(self, query, k=5):
        return self.vectorstore.similarity_search_with_score(query, k=k)

    def get_document_embedding(self, text):
        return self.embeddings.embed_query(text)

# Build the RAG knowledge base
# from langchain.document_loaders import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter


def build_rag_knowledge_base(segregated, project_aim, config_files):
    manager = VectorEmbeddingManager()
    documents = []
    # add README
    if project_aim:
        documents.append(Document(page_content=project_aim, metadata={'source':'README.md'}))
    # add config files
    for name, content in config_files.items():
        documents.append(Document(page_content=content, metadata={'source':name}))
    # add code files
    for ext, paths in segregated.items():
        for p in paths:
            try:
                tm = open(p,'r',encoding='utf-8',errors='ignore').read()
                documents.append(Document(page_content=tm, metadata={'source':os.path.basename(p), 'lang':ext}))
            except:
                pass
    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    docs = splitter.split_documents(documents)
    vs = manager.create_vectorstore(docs)
    return vs, manager