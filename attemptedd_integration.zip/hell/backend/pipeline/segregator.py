import os, shutil
from .config import EXT_DIRS

def segregate_files(extract_root: str):
    segregated = {ext: [] for ext in EXT_DIRS}
    special_dirs = {k: [] for k in ['components','pages','hooks','services','utils','assets','styles','api','tests']}

    for root, dirs, files in os.walk(extract_root):
        if any(x in root for x in ['node_modules','dist','.git']):
            continue
        rel = os.path.relpath(root, extract_root).lower()
        match = next((k for k in special_dirs if k in rel), None)
        for fn in files:
            ext = fn.split('.')[-1].lower()
            if ext in EXT_DIRS:
                src = os.path.join(root, fn)
                out_dir = os.path.join('code_dump', ext)
                os.makedirs(out_dir, exist_ok=True)
                dst = os.path.join(out_dir, fn)
                shutil.copy(src, dst)
                segregated[ext].append(dst)
                # special
                if match:
                    spec_dir = os.path.join('code_dump_organized', match)
                    os.makedirs(spec_dir, exist_ok=True)
                    shutil.copy(src, os.path.join(spec_dir, fn))
                    special_dirs[match].append(fn)
    return segregated, special_dirs