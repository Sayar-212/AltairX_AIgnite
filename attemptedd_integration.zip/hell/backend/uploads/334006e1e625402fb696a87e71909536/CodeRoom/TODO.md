1. Change the user schema - [X]
2. Update sidebar to show classes
3. add /c/[classID] route
4.
