import React from "react";

const ArchivedClasses: React.FC = () => {
	return <div>Hello, This is archived classes</div>;
};

export default ArchivedClasses;
