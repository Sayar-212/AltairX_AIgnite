// src/App.tsx
import React from "react";
import NavBar from "./components/NavBar";
import BackgroundEffects from "./components/BackgroundEffects";
import ChatWindow from "./components/ChatWindow";
// import AttachmentWrapper from "./components/AttachmentWrapper";
// import "./styles/index.css";

const App: React.FC = () => (
	<div className="app-container">
		<BackgroundEffects />

		<div className="container">
			<NavBar />

			<div className="chatbot-container">
				<div className="chat-header">
					<div className="welcome-message" />
					<h2>
						<span className="pulse-dot" /> AltairX AI Software
						Developer
					</h2>
				</div>

				<ChatWindow />

				{/* <div className="chat-input">
					<AttachmentWrapper />
					<button id="send-button">Send</button>
				</div> */}
			</div>
		</div>
	</div>
);

export default App;
