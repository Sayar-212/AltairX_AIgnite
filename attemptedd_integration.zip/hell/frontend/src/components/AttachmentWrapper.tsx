import React, { useRef } from "react";
import BubbleAnimation from "./BubbleAnimation";
import FileSelectedIndicator from "./FileSelectedIndicator";

interface AttachmentWrapperProps {
	files: File[];
	onFilesChange: (files: File[]) => void;
}

const AttachmentWrapper: React.FC<AttachmentWrapperProps> = ({
	files,
	onFilesChange,
}) => {
	const fileInputRef = useRef<HTMLInputElement>(null);
	const [showBubbles, setShowBubbles] = React.useState<boolean>(false);

	const onChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
		const fileList = e.target.files ? Array.from(e.target.files) : [];
		onFilesChange(fileList);
		if (fileList.length) {
			setShowBubbles(true);
			setTimeout(() => setShowBubbles(false), 3000);
		}
	};

	return (
		<div className="attachment-wrapper">
			<button
				type="button"
				className={`attachment-button ${files.length ? "active" : ""} ${
					showBubbles ? "uploading" : ""
				}`}
				onClick={() => fileInputRef.current?.click()}
			>
				{/* SVG icon */}
				<svg
					xmlns="http://www.w3.org/2000/svg"
					width={24}
					height={24}
					viewBox="0 0 24 24"
					fill="none"
					stroke="currentColor"
					strokeWidth={2}
					strokeLinecap="round"
					strokeLinejoin="round"
				>
					<path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48" />
				</svg>

				<div className="bubble-container">
					{showBubbles && <BubbleAnimation count={8} />}
				</div>
			</button>

			<input
				id="file-upload"
				type="file"
				multiple
				accept=".zip,.png,.jpg,.jpeg,.tiff,.pdf,.js,.html,.css,.py,.java,.cpp,.c,.php,.ts,.jsx,.tsx"
				hidden
				ref={fileInputRef}
				onChange={onChange}
			/>

			<FileSelectedIndicator files={files} />
		</div>
	);
};

export default AttachmentWrapper;
