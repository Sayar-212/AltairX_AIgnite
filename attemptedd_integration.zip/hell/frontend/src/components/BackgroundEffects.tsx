// src/components/BackgroundEffects.tsx
import React from "react";
import ParticlesBackground from "./ParticleBackground";
import StarsBackground from "./StarBackground";

const BackgroundEffects: React.FC = () => (
	<>
		<div className="gradient-blur blur-1" />
		<div className="gradient-blur blur-2" />
		<div className="gradient-blur blur-3" />

		{/* Canvas‑driven backgrounds */}
		<ParticlesBackground />
		<StarsBackground />
	</>
);

export default BackgroundEffects;
