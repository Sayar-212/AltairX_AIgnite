import React from "react";

const BubbleAnimation: React.FC<{ count: number }> = ({ count }) => {
	const bubbles = Array.from({ length: count }, (_, i) => ({
		id: i,
		left: 30 + Math.random() * 40, // %
		delay: Math.random(),
	}));

	return (
		<div className="bubble-container">
			{bubbles.map((b) => (
				<div
					key={b.id}
					className="bubble"
					style={{
						left: `${b.left}%`,
						animationDelay: `${b.delay}s`,
					}}
				/>
			))}
		</div>
	);
};

export default BubbleAnimation;
