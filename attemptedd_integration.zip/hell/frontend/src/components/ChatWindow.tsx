import React, { useState, useRef, useEffect } from "react";
import AttachmentWrapper from "./AttachmentWrapper";

interface Message {
	text: string;
	isUser: boolean;
}

const ChatWindow: React.FC = () => {
	const [messages, setMessages] = useState<Message[]>([]);
	const [typing, setTyping] = useState<boolean>(false);
	const [files, setFiles] = useState<File[]>([]);
	const inputRef = useRef<HTMLInputElement>(null);
	const scrollRef = useRef<HTMLDivElement>(null);

	useEffect(() => {
		scrollRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages]);

	const handleFilesChange = (selected: File[]) => {
		setFiles(selected);
	};

	const sendMessage = async (): Promise<void> => {
		const inputEl = inputRef.current;
		const text = inputEl?.value.trim();
		if ((!text && files.length === 0) || typing) return;

		// Add user's message
		if (text) {
			setMessages((prev) => [...prev, { text, isUser: true }]);
		}

		setTyping(true);

		try {
			// Prepare form data for file upload + message
			const formData = new FormData();
			// if (text) formData.append("message", text);
			files.forEach((file) => formData.append("file", file));

			// send to backend
			const response = await fetch("http://localhost:8000/process-zip", {
				method: "POST",
				body: formData,
			});

			const data = await response.json();
			setMessages((prev) => [
				...prev,
				{ text: data.response || "Upload successful", isUser: false },
			]);
		} catch (error) {
			console.error(error);
			setMessages((prev) => [
				...prev,
				{ text: "Oops, something went wrong.", isUser: false },
			]);
		} finally {
			setTyping(false);
			// reset input and files
			if (inputEl) inputEl.value = "";
			setFiles([]);
		}
	};

	const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>): void => {
		if (e.key === "Enter") {
			sendMessage();
		}
	};

	return (
		<div className="chat-window">
			<div className="chat-messages">
				{/* initial greeting omitted for brevity */}
				<div className="message-container">
					<div className="bot-avatar">
						<img
							src="cropped_image.png"
							alt="Bot Avatar"
							width="40"
							height="40"
						/>
					</div>
					<div className="message-content">
						<div className="message bot-message">
							Hello! I'm your AltairX AI Code Assistant. I'm here
							to help you analyze your GitHub repositories,
							identify issues, and deliver optimized code with
							detailed improvement suggestions. Simply upload your
							project or share a repository link, and I'll provide
							comprehensive code review and enhancement
							recommendations.
							<div className="shine-effect"></div>
						</div>
					</div>
				</div>
				{messages.map((msg, idx) => (
					<div key={idx} className="message-container">
						{!msg.isUser && (
							<div className="bot-avatar">
								<img
									src="/cropped_image.png"
									alt="Bot Avatar"
									width={40}
									height={40}
								/>
							</div>
						)}
						<div className="message-content">
							<div
								className={`message ${
									msg.isUser ? "user-message" : "bot-message"
								}`}
							>
								{msg.text}
								<div className="shine-effect" />
							</div>
						</div>
					</div>
				))}
				{typing && (
					<div className="typing-indicator">
						<span />
						<span />
						<span />
					</div>
				)}
				<div ref={scrollRef} />
			</div>

			<div className="chat-input">
				<input
					ref={inputRef}
					id="user-input"
					onKeyPress={handleKeyPress}
					placeholder="Type a message or attach a file..."
				/>
				<AttachmentWrapper
					files={files}
					onFilesChange={handleFilesChange}
				/>
				<button
					id="send-button"
					onClick={sendMessage}
					disabled={typing}
				>
					Send
				</button>
			</div>
		</div>
	);
};

export default ChatWindow;
