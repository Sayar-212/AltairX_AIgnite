import React from "react";

interface FileSelectedIndicatorProps {
	files: File[];
}

const FileSelectedIndicator: React.FC<FileSelectedIndicatorProps> = ({
	files,
}) => {
	if (!files.length) return null;

	const text =
		files.length === 1 ? files[0].name : `${files.length} files selected`;

	return <span className="file-selected">{text}</span>;
};

export default FileSelectedIndicator;
