// import React from "react";
// import logoSrc from "../assets/Logo.png"; // adjust path as needed
// import avatarSrc from "../assets/cropped_image.png";

export default function NavBar() {
	return (
		<nav className="nav">
			<div className="logo-container">
				<div className="logo-icon">
					{/* <img
						src={logoSrc}
						alt="Altair Logo"
						className="logo-image"
					/> */}
				</div>
				<a href="/" className="logo">
					Alt<span>airX</span>
				</a>
			</div>
		</nav>
	);
}
