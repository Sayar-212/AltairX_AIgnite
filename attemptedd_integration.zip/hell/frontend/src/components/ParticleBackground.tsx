import React, { useEffect, useRef } from "react";

const ParticlesBackground: React.FC = () => {
	const containerRef = useRef<HTMLDivElement>(null);

	useEffect(() => {
		const cnt = containerRef.current;
		if (!cnt) return;

		const createParticle = () => {
			const p = document.createElement("div");
			p.className = "particle";
			const size = Math.random() * 3 + 1;
			p.style.width = p.style.height = `${size}px`;
			p.style.opacity = `${Math.random() * 0.5 + 0.1}`;
			p.style.left = `${Math.random() * window.innerWidth}px`;
			p.style.top = `${Math.random() * window.innerHeight}px`;
			cnt.appendChild(p);
			animate(p);
		};

		const animate = (p: HTMLDivElement) => {
			const duration = Math.random() * 20000 + 10000;
			const startX = parseFloat(p.style.left);
			const startY = parseFloat(p.style.top);
			const tx = Math.random() * window.innerWidth;
			const ty = Math.random() * window.innerHeight;
			let start: number | null = null;

			function step(timestamp: number) {
				if (!start) start = timestamp;
				const prog = (timestamp - start) / duration;
				if (prog < 1) {
					p.style.left = `${startX + (tx - startX) * prog}px`;
					p.style.top = `${startY + (ty - startY) * prog}px`;
					requestAnimationFrame(step);
				} else {
					p.style.left = `${tx}px`;
					p.style.top = `${ty}px`;
					animate(p);
				}
			}

			requestAnimationFrame(step);
		};

		for (let i = 0; i < 50; i++) createParticle();
	}, []);

	return <div id="particles" ref={containerRef} />;
};

export default ParticlesBackground;
