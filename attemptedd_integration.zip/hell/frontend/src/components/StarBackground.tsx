import React, { useEffect, useRef } from "react";

const StarsBackground: React.FC = () => {
	const containerRef = useRef<HTMLDivElement>(null);

	useEffect(() => {
		const cnt = containerRef.current;
		if (!cnt) return;

		for (let i = 0; i < 100; i++) {
			const star = document.createElement("div");
			star.className = "star";
			const size = Math.random() * 2 + 1;
			star.style.width = star.style.height = `${size}px`;
			star.style.left = `${Math.random() * window.innerWidth}px`;
			star.style.top = `${Math.random() * window.innerHeight}px`;
			star.style.animationDelay = `${Math.random() * 4}s`;
			cnt.appendChild(star);
		}
	}, []);

	return <div id="stars-container" ref={containerRef} />;
};

export default StarsBackground;
