// ZipUpload.tsx
import React, { useState } from "react";
import axios from "axios";

const ZipUpload = () => {
	const [file, setFile] = useState<File | null>(null);

	const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const selectedFile = e.target.files?.[0];
		if (selectedFile && selectedFile.type === "application/zip") {
			setFile(selectedFile);
		} else {
			alert("Please upload a valid .zip file.");
		}
	};

	const handleUpload = async () => {
		if (!file) return alert("No file selected.");

		const formData = new FormData();
		formData.append("file", file);

		try {
			const res = await axios.post(
				"http://localhost:8000/upload",
				formData,
				{
					headers: {
						"Content-Type": "multipart/form-data",
					},
				}
			);

			console.log("Upload success:", res.data);
		} catch (err) {
			console.error("Upload error:", err);
		}
	};

	return (
		<div className="p-4 border rounded max-w-sm">
			<input type="file" accept=".zip" onChange={handleFileChange} />
			<button
				onClick={handleUpload}
				className="mt-2 bg-blue-600 text-white px-3 py-1 rounded"
			>
				Upload
			</button>
		</div>
	);
};

export default ZipUpload;
